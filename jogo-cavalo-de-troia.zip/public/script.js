
const socket = io();
const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');

const players = {};
let myId = null;

socket.on('init', data => {
  Object.assign(players, data.players);
  myId = data.id;
});

socket.on('new-player', ({ id, data }) => {
  players[id] = data;
});

socket.on('update', ({ id, data }) => {
  players[id] = data;
});

socket.on('remove-player', id => {
  delete players[id];
});

document.addEventListener('keydown', e => {
  if (e.key === 'ArrowLeft') socket.emit('move', 'left');
  if (e.key === 'ArrowRight') socket.emit('move', 'right');
  if (e.key === 'ArrowUp') socket.emit('move', 'up');
  if (e.key === 'ArrowDown') socket.emit('move', 'down');
  if (e.key === ' ') socket.emit('attack');
});

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  ctx.fillStyle = 'saddlebrown';
  ctx.fillRect(250, 150, 100, 100);
  ctx.strokeStyle = '#000';
  ctx.strokeRect(250, 150, 100, 100);

  for (const id in players) {
    const p = players[id];
    if (p.hidden && myId !== id && players[myId]?.team === 'trojan') continue;

    ctx.fillStyle = p.team === 'greek' ? 'blue' : 'red';
    ctx.fillRect(p.x, p.y, 30, 30);

    ctx.fillStyle = 'black';
    ctx.font = '12px Arial';
    ctx.fillText(`${p.role} (${p.hp})`, p.x, p.y - 5);
  }

  requestAnimationFrame(draw);
}

draw();
