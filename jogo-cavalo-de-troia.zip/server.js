
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static('public'));

const players = {};
const teams = {};

io.on('connection', socket => {
  console.log('Novo jogador conectado:', socket.id);

  const team = Object.values(teams).filter(t => t === 'greek').length <= Object.values(teams).filter(t => t === 'trojan').length ? 'greek' : 'trojan';
  const role = Math.random() < 0.5 ? 'warrior' : 'archer';
  teams[socket.id] = team;

  players[socket.id] = { x: 100, y: 100, hidden: false, team, role, hp: 100 };

  socket.emit('init', { players, id: socket.id });
  socket.broadcast.emit('new-player', { id: socket.id, data: players[socket.id] });

  socket.on('move', dir => {
    const speed = 5;
    const player = players[socket.id];
    if (!player) return;

    if (dir === 'left') player.x -= speed;
    if (dir === 'right') player.x += speed;
    if (dir === 'up') player.y -= speed;
    if (dir === 'down') player.y += speed;

    const inHorse = player.x > 250 && player.x < 350 && player.y > 150 && player.y < 250;
    player.hidden = (inHorse && player.team === 'greek');

    io.emit('update', { id: socket.id, data: player });
  });

  socket.on('attack', () => {
    const attacker = players[socket.id];
    if (!attacker) return;

    for (const id in players) {
      if (id === socket.id) continue;
      const target = players[id];

      const dx = target.x - attacker.x;
      const dy = target.y - attacker.y;
      const distance = Math.sqrt(dx * dx + dy * dy);

      const range = attacker.role === 'archer' ? 150 : 40;
      const damage = attacker.role === 'archer' ? 15 : 30;

      if (distance < range && attacker.team !== target.team) {
        target.hp -= damage;
        if (target.hp <= 0) {
          delete players[id];
          delete teams[id];
          io.emit('remove-player', id);
        } else {
          io.emit('update', { id, data: target });
        }
      }
    }
  });

  socket.on('disconnect', () => {
    delete players[socket.id];
    delete teams[socket.id];
    io.emit('remove-player', socket.id);
  });
});

server.listen(3000, () => {
  console.log('Servidor rodando em http://localhost:3000');
});
